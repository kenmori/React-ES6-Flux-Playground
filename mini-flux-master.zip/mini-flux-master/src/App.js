// LICENSE : MIT
"use strict";
import React from "react"
import Component from './Component';
React.render(
    React.createElement(Component),
    document.body
);