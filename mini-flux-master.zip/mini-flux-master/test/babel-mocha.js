require("babel/register")({
    plugins: ["babel-plugin-espower"]
});