# mini-flux

mini flux implement for DEMO.

- No dependent library
- EventEmitter only.(not use Flux's Dispatch)
    - just mean that this implement not handle order of events
    

## Installation

    npm install

## Usage

    npm run build
    open index.html

## Test

    npm test

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## License

MIT